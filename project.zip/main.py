import persistence
from persistence import repo

import sys
import importlib  # The imp module is deprecated in favor of importlib since version 3.4



def main():
    repo.create_tables()  # CREATES EMPTY DATABASE WITH THE TABLES WE NEED

    # READING AND INSERT DATA FROM CONFIG.TXT TO THE DATABASE
    with open(sys.argv[1], 'r') as f:  # "WITH" USED TO CLOSE THE FILE AUTOMATICALLY WHEN FINISH READING
        lines = f.readlines()  # READS ALL THE LINES FROM THE TXT FILE AND RETURN THEM AS A LIST OF STRINGS

    number_of_entries = lines[0].split(",")  # FIRST LINE HOLDS THE NUMBER OF HATS AND SUPPLIERS

    type_of_hats_num = int(number_of_entries[0])
    print("Number of different Hats: " + str(type_of_hats_num))

    type_of_suppliers_num = int(number_of_entries[1])
    print("Number of different Suppliers: " + str(type_of_suppliers_num))

    for i in range(type_of_hats_num):
        hats_values = lines[i + 1].split(",")
        record = persistence.Hat(*hats_values)
        repo.hats.insert(record)

    for j in range(type_of_hats_num + 1, len(lines)):
        suppliers_values = lines[j].split(",")
        if (j == len(lines) - 1):
            suppliers_values[1] += "\n"
        suppliers_values[1] = suppliers_values[1][:len(suppliers_values[1])-1]
        record = persistence.Supplier(*suppliers_values)
        repo.suppliers.insert(record)


    # ORDERS

    order_id = 1
    lines_to_summary = []

    with open(sys.argv[2], 'r') as f:  # "WITH" USED TO CLOSE THE FILE AUTOMATICALLY WHEN FINISH READING
        order_lines = f.readlines()  # READS ALL THE LINES FROM THE TXT FILE AND RETURN THEM AS A LIST OF STRINGS

        last_order_index = len(order_lines)-1
        counter = 0

        for i in order_lines:
            args = i.split(",")
            to_slice = args[1]

            if not counter==last_order_index:
                topping = to_slice[: int(len(to_slice))-1]

            if counter==last_order_index:
                topping = to_slice

            location = args[0]
            counter = counter + 1

            if repo.hats.topping_exist(topping):

                supplier_id = repo.hats.get_supplier_id(topping)  # get the minimum matching supplier id
                matching_hat_id = repo.hats.get_matching_hat_id(topping, supplier_id)  # get the hat id matching to the given supplier id
                supplier_with_line_space = repo.suppliers.get_name_by_id(supplier_id)  # get the matching supplier name
                supplier = supplier_with_line_space

                repo.hats.decrease_quantity(topping, matching_hat_id)  # decrease the quantity of hats from the matching entry

                order = persistence.Order(order_id, location, matching_hat_id)
                repo.orders.insert(order)

                lines_to_summary.append(topping+","+supplier+","+location)
                order_id = order_id + 1

    # SUMMARY
    with open(sys.argv[3], "a+") as f:  # "WITH" USED TO CLOSE THE FILE AUTOMATICALLY WHEN FINISH READING
        appendEOL = False
        # Move read cursor to the start of file.
        f.seek(0)
        # Check if file is not empty
        data = f.read(100)
        if len(data) > 0:
            appendEOL = True
        # Iterate over each string in the list
        for line in lines_to_summary:
            # If file is not empty then append '\n' before first line
            # For other lines always append '\n' before appending line
            if appendEOL == True:
                f.write("\n")
            else:
                appendEOL = True
            # Append element at the end of file
            f.write(line)



if __name__ == '__main__':
    main()


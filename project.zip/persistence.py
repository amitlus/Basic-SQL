# file: persistence.py

import sqlite3
import atexit
import sys


# Data Transfer Objects:
class Hat(object):
    def __init__(self, id, topping, supplier, quantity):
        self.id = id
        self.topping = topping
        self.supplier = supplier
        self.quantity = quantity


class Supplier(object):
    def __init__(self, id, name):
        self.id = id
        self.name = name


class Order(object):
    def __init__(self, id, location, hat):
        self.id = id
        self.location = location
        self.hat = hat


# Data Access Objects:
# All of these are meant to be singletons
class _Hats:
    def __init__(self, conn):
        self._conn = conn

    def insert(self, hat):
        self._conn.execute("""
               INSERT INTO hats (id, topping, supplier, quantity) VALUES (?, ?, ?, ?)
           """, [hat.id, hat.topping, hat.supplier, hat.quantity])

    def topping_exist(self, topping):  # CHECKS WHETHER A SPECIFIC TOPPING IS AVAILABLE
        c = self._conn.cursor()
        c.execute("""
                      SELECT id FROM hats WHERE topping = ?
                  """, [topping])
        record = c.fetchone()
        if record is not None:
            return True
        return False

    def get_supplier_id(self, topping):
        c = self._conn.cursor()
        c.execute("""
                    SELECT MIN(supplier) FROM hats WHERE topping = ?
                    """, [topping])
        return c.fetchone()[0]

    def get_matching_hat_id(self, topping, supplier_id):
        c = self._conn.cursor()
        c.execute("""
                                        SELECT id FROM hats WHERE topping = ? AND supplier = ?
                                """, [topping, supplier_id])
        return c.fetchone()[0]

    def decrease_quantity(self, topping, hat_id):
        c = self._conn.cursor()
        c.execute("""
                    UPDATE hats SET quantity = quantity-1 WHERE topping = ? AND id = ?
                    """, [topping, hat_id])

        c.execute("""
                                      SELECT quantity FROM hats WHERE topping = ? AND id = ?
                                  """, [topping, hat_id])
        # print("Quantity: "+int(c.fetchone()[0]))
        if int(c.fetchone()[0]) == 0:
            c.execute("""
                        DELETE FROM hats WHERE topping = ? AND id = ?
                     """, [topping, hat_id])


class _Suppliers:
    def __init__(self, conn):
        self._conn = conn

    def insert(self, supplier):
        self._conn.execute("""
            INSERT INTO suppliers (id, name) VALUES (?, ?)
        """, [supplier.id, supplier.name])

    def get_name_by_id(self, supplier_id):
        c = self._conn.cursor()
        c.execute("""
                    SELECT name FROM suppliers WHERE id = ?
                     """, [supplier_id])
        return c.fetchone()[0]


class _Orders:
    def __init__(self, conn):
        self._conn = conn

    def insert(self, order):
        self._conn.execute("""
            INSERT INTO orders (id, location, hat) VALUES (?, ?, ?)
        """, [order.id, order.location, order.hat])


# The Repository
class _Repository(object):
    def __init__(self):
        self._conn = sqlite3.connect(sys.argv[4])
        self.hats = _Hats(self._conn)
        self.suppliers = _Suppliers(self._conn)
        self.orders = _Orders(self._conn)

    def _close(self):
        self._conn.commit()
        self._conn.close()

    def create_tables(self):
        self._conn.executescript("""
                CREATE TABLE "orders" (
                   "id"	INTEGER,
                   "location"	TEXT NOT NULL,
                   "hat"	INTEGER,
                   FOREIGN KEY("hat") REFERENCES "hats"("id"),
                   PRIMARY KEY("id")
               );
               
               CREATE TABLE "hats" (
                   "id"	INTEGER,
                   "topping"	TEXT NOT NULL,
                   "supplier"	INTEGER,
                   "quantity"	INTEGER NOT NULL,
                   FOREIGN KEY("supplier") REFERENCES "suppliers"("id"),
                   PRIMARY KEY("id")
               );
       
               CREATE TABLE "suppliers" (
                   "id"	INTEGER,
                   "name"	TEXT NOT NULL,
                   PRIMARY KEY("id")
               );
           """)


# the repository singleton
repo = _Repository()
atexit.register(repo._close)
